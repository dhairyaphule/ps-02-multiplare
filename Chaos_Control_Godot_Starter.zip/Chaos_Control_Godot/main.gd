extends Node3D
# Chaos Control: local two-player 3D prototype for Godot 4.
# P1 is Objective Runner (WASD); P2 is Saboteur (arrow keys).
# Press E near a console as Runner. Saboteur presses SPACE to trigger a trap.
# Each round lasts 60 seconds. Roles swap after each round.

var runner_pos := Vector3(-7, 0.9, 0)
var sab_pos := Vector3(7, 0.9, 0)
var runner_speed := 6.0
var sab_speed := 5.0
var round_time := 60.0
var time_left := 60.0
var score_runner := 0
var score_sab := 0
var round_no := 1
var role_swap := false
var objective_progress := 0.0
var trap_cooldown := 0.0
var message := "Runner: reach the glowing console and hold E. Saboteur: use SPACE near a trap!"
var game_over := false
var runner: CharacterBody3D
var saboteur: CharacterBody3D
var console: MeshInstance3D
var trap_nodes: Array[Node3D] = []
var hud: Label
var subhud: Label
var cam: Camera3D
var world_root: Node3D
var arena_index := 0
var arena_names := ["Neon Foundry", "Toxic Reactor", "Skyline Vault"]

func _ready():
    _setup_inputs()
    _build_world()
    _make_hud()
    _update_hud()

func _setup_inputs():
    var keys = {
        "p1_forward": KEY_W, "p1_back": KEY_S, "p1_left": KEY_A, "p1_right": KEY_D,
        "p2_forward": KEY_UP, "p2_back": KEY_DOWN, "p2_left": KEY_LEFT, "p2_right": KEY_RIGHT,
        "interact": KEY_E, "trap": KEY_SPACE, "restart": KEY_R
    }
    for action in keys:
        if not InputMap.has_action(action): InputMap.add_action(action)
        var ev = InputEventKey.new()
        ev.physical_keycode = keys[action]
        InputMap.action_add_event(action, ev)

func _mat(color: Color, emission := false) -> StandardMaterial3D:
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    if emission:
        m.emission_enabled = true
        m.emission = color
        m.emission_energy_multiplier = 1.6
    return m

func _box(parent: Node3D, name: String, pos: Vector3, size: Vector3, color: Color, glow := false) -> MeshInstance3D:
    var n = MeshInstance3D.new()
    n.name = name
    var mesh = BoxMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.position = pos
    n.material_override = _mat(color, glow)
    parent.add_child(n)
    return n

func _build_world():
    if is_instance_valid(world_root):
        world_root.queue_free()
    world_root = Node3D.new()
    world_root.name = "WorldRoot"
    add_child(world_root)
    trap_nodes.clear()
    var world = WorldEnvironment.new()
    var env = Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.025, 0.035, 0.08)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.45, 0.5, 0.8)
    env.ambient_light_energy = 0.8
    world.environment = env
    world_root.add_child(world)

    # Large floor and boundary walls
    _box(world_root, "ArenaFloor", Vector3(0,-0.25,0), Vector3(22,0.5,14), Color(0.08,0.11,0.19))
    _box(world_root, "BackWall", Vector3(0,1,-7), Vector3(22,2,0.4), Color(0.13,0.18,0.32))
    _box(world_root, "FrontWall", Vector3(0,1,7), Vector3(22,2,0.4), Color(0.13,0.18,0.32))
    _box(world_root, "LeftWall", Vector3(-11,1,0), Vector3(0.4,2,14), Color(0.13,0.18,0.32))
    _box(world_root, "RightWall", Vector3(11,1,0), Vector3(0.4,2,14), Color(0.13,0.18,0.32))

    # Three arenas change their obstacle layout.
    if arena_index == 0:
        _box(world_root,"CoverA",Vector3(-2,0.6,-2),Vector3(1.4,1.2,3),Color(0.18,0.35,0.55))
        _box(world_root,"CoverB",Vector3(3,0.6,2),Vector3(2,1.2,1.4),Color(0.18,0.35,0.55))
    elif arena_index == 1:
        _box(world_root,"ReactorA",Vector3(0,0.7,0),Vector3(2,1.4,2),Color(0.25,0.5,0.24))
        _box(world_root,"ReactorB",Vector3(-4,0.5,3),Vector3(1,1,3),Color(0.25,0.5,0.24))
        _box(world_root,"ReactorC",Vector3(4,0.5,-3),Vector3(1,1,3),Color(0.25,0.5,0.24))
    else:
        _box(world_root,"VaultA",Vector3(-3,0.6,0),Vector3(1,1.2,5),Color(0.45,0.25,0.55))
        _box(world_root,"VaultB",Vector3(3,0.6,0),Vector3(1,1.2,5),Color(0.45,0.25,0.55))
        _box(world_root,"VaultC",Vector3(0,0.4,-3),Vector3(3,0.8,1),Color(0.45,0.25,0.55))

    # Interactive trap pads
    for p in [Vector3(-4,0.05,0), Vector3(0,0.05,3), Vector3(4,0.05,-2)]:
        var pad = _box(world_root,"TrapPad",p,Vector3(1.5,0.12,1.5),Color(1,0.15,0.28),true)
        trap_nodes.append(pad)

    console = _box(world_root,"ObjectiveConsole",Vector3(0,0.65,-5),Vector3(1.3,1.3,0.8),Color(0.1,0.95,1),true)

    runner = _make_player("Runner", Color(0.15,0.9,1), runner_pos)
    saboteur = _make_player("Saboteur", Color(1,0.25,0.5), sab_pos)

    cam = Camera3D.new()
    cam.position = Vector3(0,17,19)
    cam.rotation_degrees = Vector3(-42,0,0)
    cam.current = true
    world_root.add_child(cam)
    # Decorative neon lanes
    for z in [-5.8,5.8]:
        _box(world_root,"NeonLane",Vector3(0,0.03,z),Vector3(18,0.04,0.08),Color(0.1,0.8,1),true)

func _make_player(nm: String, color: Color, pos: Vector3) -> CharacterBody3D:
    var body = CharacterBody3D.new()
    body.name = nm
    body.position = pos
    var mesh = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.radius = 0.48
    capsule.height = 1.6
    mesh.mesh = capsule
    mesh.material_override = _mat(color, true)
    body.add_child(mesh)
    var col = CollisionShape3D.new()
    var shape = CapsuleShape3D.new()
    shape.radius = 0.48
    shape.height = 1.6
    col.shape = shape
    body.add_child(col)
    world_root.add_child(body)
    return body

func _make_hud():
    var layer = CanvasLayer.new()
    add_child(layer)
    var panel = ColorRect.new()
    panel.color = Color(0.015,0.025,0.07,0.88)
    panel.position = Vector2(14,14)
    panel.size = Vector2(650,112)
    layer.add_child(panel)
    hud = Label.new()
    hud.position = Vector2(28,20)
    hud.add_theme_font_size_override("font_size", 20)
    hud.add_theme_color_override("font_color", Color(0.55,0.95,1))
    hud.size = Vector2(620,50)
    layer.add_child(hud)
    subhud = Label.new()
    subhud.position = Vector2(28,66)
    subhud.size = Vector2(1120,80)
    subhud.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    subhud.add_theme_font_size_override("font_size", 16)
    subhud.add_theme_color_override("font_color", Color(1,1,1))
    layer.add_child(subhud)

func _process(delta):
    if Input.is_action_just_pressed("restart") and game_over:
        _restart_game()
    if game_over: return
    time_left -= delta
    trap_cooldown = max(0.0, trap_cooldown - delta)
    _move_players(delta)
    _check_console(delta)
    _check_traps()
    if time_left <= 0:
        _finish_round()
    _update_hud()

func _move_players(delta):
    var runner_dir = Vector3(
        Input.get_action_strength("p1_right") - Input.get_action_strength("p1_left"), 0,
        Input.get_action_strength("p1_back") - Input.get_action_strength("p1_forward")
    ).normalized()
    var sab_dir = Vector3(
        Input.get_action_strength("p2_right") - Input.get_action_strength("p2_left"), 0,
        Input.get_action_strength("p2_back") - Input.get_action_strength("p2_forward")
    ).normalized()
    # Role swap changes which player is the active runner.
    if not role_swap:
        runner_pos += runner_dir * runner_speed * delta
        sab_pos += sab_dir * sab_speed * delta
    else:
        runner_pos += runner_dir * runner_speed * delta
        sab_pos += sab_dir * sab_speed * delta
    runner_pos.x = clamp(runner_pos.x, -9.8, 9.8)
    runner_pos.z = clamp(runner_pos.z, -5.8, 5.8)
    sab_pos.x = clamp(sab_pos.x, -9.8, 9.8)
    sab_pos.z = clamp(sab_pos.z, -5.8, 5.8)
    runner.position = runner_pos
    saboteur.position = sab_pos

func _check_console(delta):
    if runner_pos.distance_to(console.position) < 2.0 and Input.is_action_pressed("interact"):
        objective_progress += delta * 25.0
        message = "Console hacked: %.0f%% — keep holding E!" % objective_progress
        if objective_progress >= 100:
            score_runner += 1
            _finish_round(true)
    else:
        objective_progress = max(0.0, objective_progress - delta * 8.0)

func _check_traps():
    if Input.is_action_just_pressed("trap") and trap_cooldown <= 0:
        var closest = trap_nodes[0]
        var best = 999.0
        for pad in trap_nodes:
            var d = sab_pos.distance_to(pad.position)
            if d < best:
                best = d
                closest = pad
        if best < 7.0:
            trap_cooldown = 5.0
            if runner_pos.distance_to(closest.position) < 2.5:
                runner_pos = Vector3(-7,0.9,0)
                runner.position = runner_pos
                message = "SABOTAGE! Runner sent back to spawn. Trap cooldown: 5s."
            else:
                message = "Trap armed! Get the Runner to step on a red pad. Cooldown: 5s."
        else:
            message = "Move near a red trap pad to trigger sabotage."

func _finish_round(runner_won := false):
    if not runner_won:
        score_sab += 1
        message = "TIME'S UP — Saboteur wins the round!"
    else:
        message = "OBJECTIVE COMPLETE — Runner wins the round!"
    if round_no >= 6:
        game_over = true
        message += " MATCH OVER! Press R to restart."
    else:
        round_no += 1
        role_swap = not role_swap
        arena_index = (arena_index + 1) % arena_names.size()
        time_left = round_time
        objective_progress = 0
        runner_pos = Vector3(-7,0.9,0)
        sab_pos = Vector3(7,0.9,0)
        _build_world()
        message += " Roles switched. Next arena: " + arena_names[arena_index]

func _restart_game():
    score_runner = 0
    score_sab = 0
    round_no = 1
    role_swap = false
    arena_index = 0
    time_left = round_time
    objective_progress = 0
    game_over = false
    runner_pos = Vector3(-7,0.9,0)
    sab_pos = Vector3(7,0.9,0)
    _build_world()
    message = "New match! Runner: hold E at console. Saboteur: SPACE near traps."

func _update_hud():
    if not is_instance_valid(hud): return
    hud.text = "CHAOS CONTROL  |  %s  |  ROUND %d/6  |  TIME %02d" % [arena_names[arena_index], round_no, int(max(0,time_left))]
    var roles = "P1 Runner (WASD + E)  •  P2 Saboteur (Arrows + SPACE)"
    if role_swap: roles = "ROLES SWITCHED: P1 Runner (WASD + E)  •  P2 Saboteur (Arrows + SPACE)"
    subhud.text = "%s\nScore — Runner: %d   Saboteur: %d   |   Console progress: %d%%\n%s\nR = restart after match" % [roles, score_runner, score_sab, int(objective_progress), message]
