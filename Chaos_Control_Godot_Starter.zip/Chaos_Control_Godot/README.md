# Chaos Control — Godot 4 beginner prototype

## Run it
1. Install Godot 4.x (free) from https://godotengine.org/download/
2. Extract this ZIP.
3. Open Godot Project Manager → Import → select `project.godot` inside this folder.
4. Open the project and press F6 (run current scene) or F5 (run project).

## Controls
- Player 1 / Runner: W A S D to move; hold E near the cyan console at the back of the arena.
- Player 2 / Saboteur: arrow keys to move; press SPACE near a red trap pad to trigger sabotage.
- R restarts after the match ends.
- Rounds are timed; roles switch each round and the arena layout cycles through three arenas.

## Prototype notes
- This is an offline, same-keyboard 3D prototype.
- Built from primitive 3D meshes, so it needs no external assets.
- The game has six rounds, a timer, scores, trap interaction, role switching, three arena layouts, and a restart.
- The role names and on-screen instructions are included for the hackathon demo.
- For judging, test both roles and describe it as a local multiplayer prototype, not online multiplayer.

## 24-hour polish plan
1. First 2 hours: import and confirm it runs.
2. Next 4 hours: test movement, console, traps, scoring, and restart.
3. Next 4 hours: tune speeds and console distance.
4. Next 4 hours: add sounds and a title screen if time permits.
5. Next 4 hours: build export for Windows or web (web export may need template setup).
6. Final 6 hours: rehearse a 2-minute demo and keep a backup copy.
